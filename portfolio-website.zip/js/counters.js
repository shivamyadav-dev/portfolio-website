// ========================================
// Animated Counter Statistics
// ========================================

class CounterAnimations {
    constructor() {
        this.observerOptions = {
            threshold: 0.5,
            rootMargin: '0px'
        };
        
        this.init();
    }
    
    init() {
        this.observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !entry.target.classList.contains('animated')) {
                    entry.target.classList.add('animated');
                    this.animateCounter(entry.target);
                }
            });
        }, this.observerOptions);
        
        // Observe all stat values
        document.querySelectorAll('.stat-value').forEach(stat => {
            this.observer.observe(stat);
        });
    }
    
    animateCounter(element) {
        const target = parseInt(element.getAttribute('data-target'));
        if (isNaN(target)) return;
        
        const duration = 2000; // 2 seconds
        const steps = 50; // 50-step increment
        const increment = target / steps;
        const stepDuration = duration / steps;
        
        let current = 0;
        let step = 0;
        
        const timer = setInterval(() => {
            step++;
            current = Math.min(increment * step, target);
            
            element.textContent = Math.floor(current);
            
            if (step >= steps) {
                element.textContent = target;
                clearInterval(timer);
            }
        }, stepDuration);
    }
    
    // Method to observe new counters dynamically added
    observeNewCounter(element) {
        this.observer.observe(element);
    }
}

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', () => {
    window.counterAnimations = new CounterAnimations();
});

