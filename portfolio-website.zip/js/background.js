// ========================================
// Canvas Background Animation
// Neural Network Nodes, Data Streams, Math Symbols, Grid, Particles
// ========================================

class NeuralNetworkCanvas {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.nodes = [];
        this.streams = [];
        this.symbols = [];
        this.particles = [];
        this.animationId = null;
        this.gridSpacing = 80;
        this.connectionDistance = 150;
        
        this.resize();
        this.initNodes();
        this.initStreams();
        this.initSymbols();
        this.initParticles();
        this.animate();
        
        window.addEventListener('resize', () => this.resize());
    }
    
    resize() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
        // Reinitialize elements if canvas size changed significantly
        if (this.nodes.length < 60) {
            this.initNodes();
        }
        if (this.streams.length < 30) {
            this.initStreams();
        }
        if (this.symbols.length < 15) {
            this.initSymbols();
        }
        if (this.particles.length < 20) {
            this.initParticles();
        }
    }
    
    initNodes() {
        // 60 neural network nodes
        const nodeCount = 60;
        this.nodes = [];
        for (let i = 0; i < nodeCount; i++) {
            this.nodes.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                vx: (Math.random() - 0.5) * 0.3,
                vy: (Math.random() - 0.5) * 0.3,
                radius: Math.random() * 2 + 2, // 2-4px radius
                pulse: Math.random() * Math.PI * 2
            });
        }
    }
    
    initStreams() {
        // 30 data streams
        const streamCount = 30;
        this.streams = [];
        for (let i = 0; i < streamCount; i++) {
            this.streams.push({
                x: Math.random() * this.canvas.width,
                y: -50 - Math.random() * 200, // Start above viewport
                speed: Math.random() * 2 + 1, // 1-3px/frame
                length: Math.random() * 100 + 50,
                opacity: Math.random() * 0.5 + 0.3,
                dots: []
            });
            
            // Initialize dots along stream
            for (let j = 0; j < 5; j++) {
                this.streams[i].dots.push({
                    offset: j * 20,
                    size: Math.random() * 3 + 2
                });
            }
        }
    }
    
    initSymbols() {
        // 15 floating mathematical symbols
        const symbolList = ['Σ', '∞', 'π', 'λ', '∫', '∂', 'α', 'β', 'θ', 'Δ'];
        const symbolCount = 15;
        this.symbols = [];
        for (let i = 0; i < symbolCount; i++) {
            this.symbols.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                symbol: symbolList[Math.floor(Math.random() * symbolList.length)],
                size: 32,
                opacity: Math.random() * 0.4 + 0.2, // 0.2-0.6
                vx: (Math.random() - 0.5) * 0.2,
                vy: Math.random() * 0.5 + 0.3, // Slow vertical drift
                rotation: Math.random() * Math.PI * 2,
                rotationSpeed: (Math.random() - 0.5) * 0.02
            });
        }
    }
    
    initParticles() {
        // 20 floating particles
        const particleCount = 20;
        this.particles = [];
        for (let i = 0; i < particleCount; i++) {
            this.particles.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                vx: (Math.random() - 0.5) * 0.5,
                vy: Math.sin(Math.random() * Math.PI * 2) * 0.3, // Sine wave path
                radius: Math.random() * 2 + 1,
                opacity: Math.random() * 0.5 + 0.3,
                phase: Math.random() * Math.PI * 2,
                amplitude: Math.random() * 30 + 10
            });
        }
    }
    
    updateNodes() {
        this.nodes.forEach(node => {
            // Floating movement (0.3px/frame average)
            node.x += node.vx;
            node.y += node.vy;
            
            // Pulse effect
            node.pulse += 0.05;
            
            // Boundary wrapping
            if (node.x < 0) node.x = this.canvas.width;
            if (node.x > this.canvas.width) node.x = 0;
            if (node.y < 0) node.y = this.canvas.height;
            if (node.y > this.canvas.height) node.y = 0;
        });
    }
    
    updateStreams() {
        this.streams.forEach((stream, index) => {
            stream.y += stream.speed;
            
            // Reset stream when it goes off screen
            if (stream.y > this.canvas.height + stream.length) {
                stream.y = -stream.length - Math.random() * 100;
                stream.x = Math.random() * this.canvas.width;
            }
            
            // Update dots along stream
            stream.dots.forEach((dot, dotIndex) => {
                dot.offset = (dot.offset + stream.speed) % (stream.length + 20);
            });
        });
    }
    
    updateSymbols() {
        this.symbols.forEach(symbol => {
            symbol.x += symbol.vx;
            symbol.y += symbol.vy;
            symbol.rotation += symbol.rotationSpeed;
            
            // Wrap around screen
            if (symbol.x < -50) symbol.x = this.canvas.width + 50;
            if (symbol.x > this.canvas.width + 50) symbol.x = -50;
            if (symbol.y < -50) symbol.y = this.canvas.height + 50;
            if (symbol.y > this.canvas.height + 50) symbol.y = -50;
        });
    }
    
    updateParticles() {
        this.particles.forEach(particle => {
            // Sine wave path
            particle.phase += 0.02;
            particle.x += particle.vx;
            particle.y += Math.sin(particle.phase) * particle.amplitude * 0.01;
            
            // Wrap around
            if (particle.x < 0) particle.x = this.canvas.width;
            if (particle.x > this.canvas.width) particle.x = 0;
            if (particle.y < 0) particle.y = this.canvas.height;
            if (particle.y > this.canvas.height) particle.y = 0;
        });
    }
    
    drawGrid() {
        // Subtle cyan grid (80px spacing, opacity 0.08)
        this.ctx.strokeStyle = 'rgba(56, 189, 248, 0.08)';
        this.ctx.lineWidth = 1;
        
        // Vertical lines
        for (let x = 0; x < this.canvas.width; x += this.gridSpacing) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, 0);
            this.ctx.lineTo(x, this.canvas.height);
            this.ctx.stroke();
        }
        
        // Horizontal lines
        for (let y = 0; y < this.canvas.height; y += this.gridSpacing) {
            this.ctx.beginPath();
            this.ctx.moveTo(0, y);
            this.ctx.lineTo(this.canvas.width, y);
            this.ctx.stroke();
        }
    }
    
    drawConnections() {
        // Connect nodes within 150px distance with gradient lines
        for (let i = 0; i < this.nodes.length; i++) {
            for (let j = i + 1; j < this.nodes.length; j++) {
                const dx = this.nodes[i].x - this.nodes[j].x;
                const dy = this.nodes[i].y - this.nodes[j].y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < this.connectionDistance) {
                    // Gradient from cyan to transparent
                    const opacity = (this.connectionDistance - distance) / this.connectionDistance * 0.3;
                    const pulseOpacity = (Math.sin(Date.now() * 0.005 + i + j) + 1) * 0.5;
                    
                    // Create gradient
                    const gradient = this.ctx.createLinearGradient(
                        this.nodes[i].x, this.nodes[i].y,
                        this.nodes[j].x, this.nodes[j].y
                    );
                    gradient.addColorStop(0, `rgba(56, 189, 248, ${opacity * pulseOpacity})`);
                    gradient.addColorStop(1, `rgba(56, 189, 248, ${opacity * 0.5 * pulseOpacity})`);
                    
                    this.ctx.strokeStyle = gradient;
                    this.ctx.lineWidth = 1;
                    this.ctx.beginPath();
                    this.ctx.moveTo(this.nodes[i].x, this.nodes[i].y);
                    this.ctx.lineTo(this.nodes[j].x, this.nodes[j].y);
                    this.ctx.stroke();
                }
            }
        }
    }
    
    drawNodes() {
        // Cyan glowing circles
        this.nodes.forEach(node => {
            const pulseRadius = node.radius + Math.sin(node.pulse) * 0.5;
            
            // Glow effect
            this.ctx.shadowBlur = 15;
            this.ctx.shadowColor = '#38bdf8';
            
            // Outer glow
            this.ctx.beginPath();
            this.ctx.arc(node.x, node.y, pulseRadius + 2, 0, Math.PI * 2);
            this.ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
            this.ctx.fill();
            
            // Main circle
            this.ctx.beginPath();
            this.ctx.arc(node.x, node.y, pulseRadius, 0, Math.PI * 2);
            this.ctx.fillStyle = '#38bdf8';
            this.ctx.fill();
            
            this.ctx.shadowBlur = 0;
        });
    }
    
    drawStreams() {
        // Vertical flowing lines with gradient trails (cyan to purple)
        this.streams.forEach(stream => {
            const gradient = this.ctx.createLinearGradient(
                stream.x, stream.y,
                stream.x, stream.y + stream.length
            );
            gradient.addColorStop(0, `rgba(56, 189, 248, ${stream.opacity})`);
            gradient.addColorStop(0.5, `rgba(147, 51, 234, ${stream.opacity * 0.8})`);
            gradient.addColorStop(1, `rgba(56, 189, 248, 0)`);
            
            this.ctx.strokeStyle = gradient;
            this.ctx.lineWidth = 2;
            this.ctx.beginPath();
            this.ctx.moveTo(stream.x, stream.y);
            this.ctx.lineTo(stream.x, stream.y + stream.length);
            this.ctx.stroke();
            
            // Glowing dots along streams
            stream.dots.forEach(dot => {
                const dotY = stream.y + dot.offset;
                if (dotY > 0 && dotY < this.canvas.height) {
                    this.ctx.shadowBlur = 8;
                    this.ctx.shadowColor = '#38bdf8';
                    this.ctx.beginPath();
                    this.ctx.arc(stream.x, dotY, dot.size, 0, Math.PI * 2);
                    this.ctx.fillStyle = '#38bdf8';
                    this.ctx.fill();
                    this.ctx.shadowBlur = 0;
                }
            });
        });
    }
    
    drawSymbols() {
        // Mathematical symbols with purple glow
        this.symbols.forEach(symbol => {
            this.ctx.save();
            this.ctx.translate(symbol.x, symbol.y);
            this.ctx.rotate(symbol.rotation);
            
            // Purple glow effect (text-shadow simulation)
            this.ctx.shadowBlur = 15;
            this.ctx.shadowColor = 'rgba(147, 51, 234, 0.8)';
            
            this.ctx.font = `bold ${symbol.size}px 'JetBrains Mono'`;
            this.ctx.fillStyle = `rgba(147, 51, 234, ${symbol.opacity})`;
            this.ctx.textAlign = 'center';
            this.ctx.textBaseline = 'middle';
            this.ctx.fillText(symbol.symbol, 0, 0);
            
            this.ctx.shadowBlur = 0;
            this.ctx.restore();
        });
    }
    
    drawParticles() {
        // Small cyan particles
        this.particles.forEach(particle => {
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
            this.ctx.fillStyle = `rgba(56, 189, 248, ${particle.opacity})`;
            this.ctx.fill();
        });
    }
    
    animate() {
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Update all elements
        this.updateNodes();
        this.updateStreams();
        this.updateSymbols();
        this.updateParticles();
        
        // Draw in order (back to front)
        this.drawGrid();
        this.drawStreams();
        this.drawConnections();
        this.drawParticles();
        this.drawSymbols();
        this.drawNodes();
        
        // Continue animation
        this.animationId = requestAnimationFrame(() => this.animate());
    }
    
    destroy() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
        }
    }
}

// ========================================
// Initialize Canvas
// ========================================

let canvasInstance = null;

document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('backgroundCanvas');
    if (canvas) {
        canvasInstance = new NeuralNetworkCanvas(canvas);
    }
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (canvasInstance) {
        canvasInstance.destroy();
    }
});

